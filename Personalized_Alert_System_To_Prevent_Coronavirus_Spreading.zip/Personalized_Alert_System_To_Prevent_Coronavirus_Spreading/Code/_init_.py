import pandas as pd
import os
from whatsapp_msg_send import send_msg_to_whatsapp

def number_and_msg_table_geneation(base_path, df, all_sheet_names):

    df_final = pd.DataFrame()
    df['START_TIME'] = df['START_TIME'].astype(str)
    df['END_TIME'] = df['END_TIME'].astype(str)
    for idx, row in df.iterrows():
        CELL_ID_Infected = row['FIRST_CELL_ID_A']
        Date_Infected = row['DATE']
        Start_Time_Infected = row['START_TIME']
        print ("Start_Time_Infected : ", Start_Time_Infected)
        Start_Hour_Infected = int(Start_Time_Infected.split(":")[0])
        End_Time_Infected = row['END_TIME']
        End_Hour_Infected = int(End_Time_Infected.split(":")[0])
        Location_Infected = row['CELL_LOCATION']
        
        count = 0
        print ("\n\nCELL_ID_Infected : ", CELL_ID_Infected)
        for sheet_name in all_sheet_names:
            print ("\n\n sheet_name : ", sheet_name)
            df_suspected = pd.read_excel(xls, sheet_name, header=0)
            df_suspected['START_TIME'] = df_suspected['START_TIME'].astype(str)
            df_suspected['END_TIME'] = df_suspected['END_TIME'].astype(str)
            for idx, row_suspect in df_suspected.iterrows():
                CELL_ID_Suspected = row_suspect['FIRST_CELL_ID_A']
                if CELL_ID_Infected == CELL_ID_Suspected:
                    count += 1
                    Date_Suspected = row_suspect['DATE']
                    Start_Time_Suspected = row_suspect['START_TIME']
                    print ("Start_Time_Suspected : ", Start_Time_Suspected)
                    Start_Hour_Suspected = int(Start_Time_Suspected.split(":")[0])
                    
                    End_Time_Suspected = row_suspect['END_TIME']
                    print ("Start_Time_Suspected : ", End_Time_Suspected)
                    End_Hour_Suspected = int(End_Time_Suspected.split(":")[0])

                    Phone_Number_Suspected = row_suspect['Alerted_Party_No']

                    if (Date_Infected == Date_Suspected) and (((Start_Hour_Infected <= Start_Hour_Suspected) and (End_Hour_Infected+3 >= Start_Hour_Suspected)) or ((End_Hour_Infected+3 >= End_Hour_Suspected) and (Start_Hour_Infected <= End_Hour_Suspected))):
                        print ("\nsheet_name : ", sheet_name)
                        print ("Date_Infected : ", Date_Infected)
                        print ("Phone_Number_Suspected : ", Phone_Number_Suspected)
                        print ("Start_Time_Suspected : ", Start_Time_Suspected)
                        
                        Total_Spent_Time_Suspected = End_Hour_Suspected - Start_Hour_Suspected
                        Total_Spent_Time_Infected = End_Hour_Infected - Start_Hour_Infected
                        
                        temp = pd.DataFrame({'Phone_Number_Suspected': [Phone_Number_Suspected], 'Total_Spent_Time_Infected': [Total_Spent_Time_Infected], 'Total_Spent_Time_Suspected': [Total_Spent_Time_Suspected], 'Spent_Date': [Date_Suspected], 'Location': [Location_Infected]})
                        df_final = df_final.append(temp)
                else:
                    break
            if count == 1:
                break
                
    df_final = df_final.drop_duplicates(keep='first')


    df_final_msg = pd.DataFrame()
    unique_suspected_number = df_final['Phone_Number_Suspected'].unique()
    unique_suspected_date = df_final['Spent_Date'].unique()

    print ("unique_suspected_number : ", unique_suspected_number)
    print ("unique_suspected_date : ", unique_suspected_date)

    for usn in unique_suspected_number:
        days_count = 0
        total_hours = 0
        df_final_usn = df_final[df_final['Phone_Number_Suspected'] == usn]
        Locations = ""
        loc_list = []
        for usd in unique_suspected_date:
            
            df_final_usn_usd = df_final_usn[df_final_usn['Spent_Date'] == usd]
            total_hours = total_hours + sum(df_final_usn_usd['Total_Spent_Time_Suspected'])
            days_count += 1
            temp_loc = df_final_usn_usd['Location'].unique()
            for loc in temp_loc:
                if loc not in loc_list:
                    loc_list.append(loc)
                    Locations = Locations+loc+"; "
        
        message = "A corona infected person was visited in "+ str(Locations)+" area in past "+ str(days_count) +" days and you were also present in the same region on the same dates for total "+ str(total_hours) + " hours. So, please stop your movement even to your next door. If you find any symptoms of corona, then please contact to the local health care numbers."
        temp = pd.DataFrame({'Phone_Number_Suspected': [usn], 'Message': [message]})
        
        df_final_msg = df_final_msg.append(temp)
        
    result_store_path = base_path+"Result\\Phone_Number_and_Message.csv"
    df_final_msg.to_csv(result_store_path, index=False)

    return 0 


if __name__ == "__main__":
    print ("I am in IF")
    current_path = os.path.dirname(os.path.abspath(os.getcwd()))
    print ("current_path : ", current_path)
    base_path = current_path +"\\"
    # base_path = os.path.join(current_path,"\\")
    print ("base_path : ", base_path)
    input_path = base_path+"Input\\"
    for filename in os.listdir(input_path):
        print ("\n\nfilename : ", filename)
        final_path = input_path + filename
        xls = pd.ExcelFile(final_path)
        infected_sheet_names = xls.sheet_names[0]
        df = pd.read_excel(xls, infected_sheet_names, header=0)
        all_sheet_names = xls.sheet_names[1:]

        num_msg = number_and_msg_table_geneation(base_path, df, all_sheet_names)
        snd_msg = send_msg_to_whatsapp(base_path)


