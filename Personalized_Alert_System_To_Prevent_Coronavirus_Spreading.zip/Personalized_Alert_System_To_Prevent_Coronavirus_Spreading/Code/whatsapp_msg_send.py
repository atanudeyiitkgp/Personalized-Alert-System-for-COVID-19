import selenium
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import time
import pyautogui
import pandas as pd


def send_msg_to_whatsapp(base_path):
    df_for_final_msg = pd.read_csv(base_path+"\\Result\\Phone_Number_and_Message.csv")

    for idx, row_msg in df_for_final_msg.iterrows():
        
        mobile_number = row_msg['Phone_Number_Suspected']
        mobile_number = "91"+str(mobile_number)
        Msg = row_msg['Message']
        Msg = Msg.replace(" ","%20")
        
        options = Options()
        options.add_argument("--disable-infobars")    
        # options.add_argument("headless") # Runs Chrome in headless mode.

        driver = webdriver.Chrome(base_path+"Chrome_Driver\\chromedriver.exe", chrome_options=options)

        x = "https://wa.me/"+mobile_number+"?text=[Alert%20Message%20From%20Government]%20"+Msg
        # x = "https://web.whatsapp.com/918100536846?text=How%20are%20you%20?"
        # 919988776655?text=How%20are%20you%20?

        driver.get(x)

        pyautogui.press("tab")
        pyautogui.press("enter")
        time.sleep(15)
        print (" am before enter")
        pyautogui.press("enter")
        print (" am after enter")

        print ("I am In APP")

        driver.close()

    return 0